<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Preview Brand - Local</title>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Inter,Arial,sans-serif;margin:2rem;line-height:1.4}
    .grid{display:grid;gap:2rem;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}
    .card{border:1px solid #e5e7eb;border-radius:12px;padding:16px}
    .meta{color:#374151;font-size:14px;margin-top:8px}
    img{max-width:100%;height:auto;border-radius:8px;background:#f3f4f6}
    .ok{color:#065f46}
    .warn{color:#92400e}
    code{background:#f3f4f6;padding:2px 6px;border-radius:6px}
  </style>
  <meta name="robots" content="noindex, nofollow" />
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta http-equiv="Expires" content="0" />
  <link rel="icon" href="/favicon.ico" />
  <link rel="canonical" href="<?php echo e(url()->current()); ?>" />
  </head>
<body>
  <h1>Prévisualisation DA – Logo & Image sociale</h1>
  <p>Local uniquement. Vérifie que le logo et l’image social sont présents et bien dimensionnés.</p>

  <div class="grid">
    <section class="card">
      <h2>Logo</h2>
      <?php if($logo['exists']): ?>
        <img src="<?php echo e($logo['src']); ?>" alt="Logo"/>
        <div class="meta">Dimensions: <?php echo e($logo['width'] ?? '?'); ?>×<?php echo e($logo['height'] ?? '?'); ?> | Ratio: <?php echo e($logo['ratio'] ?? '?'); ?></div>
        <div class="meta">Fichier: <code><?php echo e($logo['src']); ?></code></div>
      <?php else: ?>
        <p class="warn">Logo introuvable: <code>/images/logo.png</code></p>
      <?php endif; ?>
      <p class="meta">Conseil: PNG ou SVG, fond transparent si possible.</p>
    </section>

    <section class="card">
      <h2>Image sociale (1200×630)</h2>
      <?php if($social['exists']): ?>
        <img src="<?php echo e($social['src']); ?>?t=<?php echo e(time()); ?>" alt="Social"/>
        <div class="meta">Dimensions: <?php echo e($social['width'] ?? '?'); ?>×<?php echo e($social['height'] ?? '?'); ?> | Ratio: <?php echo e($social['ratio'] ?? '?'); ?></div>
        <div class="meta">Fichier: <code><?php echo e($social['src']); ?></code></div>
        <?php if(!($social['is_1200x630'] ?? false)): ?>
          <p class="warn">Recommandé: 1200×630 (actuel différent).</p>
        <?php else: ?>
          <p class="ok">Format optimal pour réseaux sociaux 👍</p>
        <?php endif; ?>
      <?php else: ?>
        <p class="warn">Image sociale introuvable: <code>/images/social-default.jpg</code></p>
      <?php endif; ?>
      <p class="meta">Astuce: texte lisible, marge autour du logo, contraste élevé.</p>
    </section>
  </div>
  
  <p class="meta">Les partages utilisent og:image / twitter:image configurés dans la <code>&lt;head&gt;</code>.</p>
</body>
</html>
<?php /**PATH C:\laragon\www\solelec\resources\views/preview/brand.blade.php ENDPATH**/ ?>