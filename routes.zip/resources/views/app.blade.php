<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title inertia>{{ config('app.name', 'Laravel') }}</title>

    <!-- Default SEO meta -->
    <meta name="description" content="Solelec — Électricien professionnel en Wallonie et Bruxelles. Installation, maintenance et solutions photovoltaïques pour particuliers et entreprises." />
    <meta name="robots" content="index, follow" />
    @php
        $baseUrl = rtrim(config('app.url', env('APP_URL')), '/');
        $currentUrl = url()->current();
        $socialImage = "$baseUrl/images/social-default.png"; // 1200x630 recommandé
    @endphp
    <meta property="og:site_name" content="{{ config('app.name', 'Solelec') }}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="{{ config('app.name', 'Solelec') }}" />
    <meta property="og:description" content="Solelec — Électricien professionnel en Wallonie et Bruxelles. Installation, maintenance et solutions photovoltaïques." />
    <link rel="canonical" href="{{ $currentUrl }}" />
    <meta property="og:url" content="{{ $currentUrl }}" />
    <meta property="og:image" content="{{ $socialImage }}" />
    <meta property="og:image:secure_url" content="{{ $socialImage }}" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:type" content="image/png" />
    <meta property="og:image:alt" content="{{ config('app.name', 'Solelec') }}" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="{{ config('app.name', 'Solelec') }}" />
    <meta name="twitter:description" content="Installation et maintenance électrique — Solelec" />
    <meta name="twitter:image" content="{{ $socialImage }}" />
    <meta name="twitter:image:alt" content="{{ config('app.name', 'Solelec') }}" />

    <!-- JSON-LD Organization -->
    <script type="application/ld+json">
    {
    "@context": "https://schema.org",
    "@type": "Electrician",
    "name": "Solelec",
    "url": "{{ $baseUrl }}",
    "logo": "{{ $baseUrl }}/images/logo.png",
    "image": "{{ $socialImage }}",
    "description": "Solelec — Électricien professionnel en Wallonie et Bruxelles. Installation, maintenance et dépannage électrique pour particuliers et entreprises.",
    "telephone": "0492 51 09 31",
    "email": "solelec.lmbt@gmail.com",
    "address": {
        "@type": "PostalAddress",
        "streetAddress": "Rue de Neufmoustier 4",
        "addressLocality": "Ottignies-Louvain-la-Neuve",
        "postalCode": "1348",
        "addressCountry": "BE"
    },
    "areaServed": {
        "@type": "AdministrativeArea",
        "name": "Wallonie et Bruxelles",
    }
    }
</script>


    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <!-- Google Maps API -->
    <script>
        window.initMap = function() {
            // Cette fonction sera appelée quand Google Maps sera chargé
            // Et elle déclenchera un événement personnalisé
            document.dispatchEvent(new Event('google-maps-loaded'));
        }
    </script>

    <!-- Google Maps API - Correction du paramètre loading -->
    <script
        src="https://maps.googleapis.com/maps/api/js?key={{ env('VITE_GOOGLE_MAPS_API_KEY') }}&callback=initMap&loading=async"
        defer></script>

    <!-- Scripts -->
    @routes
    @vite(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"])
    <!-- Favicon: prefer .ico, fallback to PNG and SVG if available -->
    <link rel="icon" type="image/svg+xml" href="/favicon.svg?v=2">
    <link rel="icon" type="image/x-icon" href="/favicon.ico?v=2">
    <link rel="shortcut icon" href="/favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png?v=2">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png?v=2">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png?v=2">
    <meta name="msapplication-TileImage" content="/favicon.ico?v=2">
    @inertiaHead
</head>

<body class="font-sans antialiased">
    @inertia
</body>

</html>
