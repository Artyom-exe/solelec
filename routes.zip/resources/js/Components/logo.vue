<script setup>
// Pas besoin d'importer Link car nous n'utilisons plus de lien interne
</script>

<template>
    <div class="flex items-center">
        <span class="font-inter font-extrabold text-xl text-white leading-7"
            >S<span class="text-[#FF8C42]">O</span>LELEC</span
        >
    </div>
</template>
